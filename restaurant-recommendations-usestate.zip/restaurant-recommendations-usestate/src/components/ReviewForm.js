import React, {useState} from "react"

const ReviewForm = props => {
  //setting reviewRecord to {}, and pass this record up to App when user submit successfully
  const [reviewRecord, setReviewRecord] = useState({
    name: "",
    restaurant_id: 'jm-curley-boston',
    rating: 0,
    content: ""
  })

  // const ratingStars = [null,1,2,3,4,5]
  // const ratingOptions = ratingStars.map( rating => {
  //   return (
  //     <option key={rating}>{rating} </option>
  //   )
  // })

  const handleInputChange = event => {   
    setReviewRecord({
      ...reviewRecord,
      [event.currentTarget.name]: event.currentTarget.value     
      // [event.currentTarget.id]: event.currentTarget.value     
    })
  }

  const onSubmitHandler = event => {
    event.preventDefault()
    props.onReviewSubmit(reviewRecord)
  }

  const clearForm = (event) => {
    event.preventDefault()
    setReviewRecord({name: "",restaurant_id: 'jm-curley-boston', rating: 0, content: ""})
  }


  return (
    <div>
      <form className="callout" onSubmit={onSubmitHandler}>

        <label htmlFor="name">Name
          <input id="name" type="text" name="name" onChange={handleInputChange} value={reviewRecord.name}/>
        </label>

        <label htmlFor="rating">Rating: 
          {/* <select id="rating" name="rating" onChange={handleInputChange} value={reviewRecord.rating}>{ratingOptions}</select> */}
           1<input type="radio" id="rating-1" name="rating" onChange={handleInputChange} value="20" />
           2<input type="radio" id="rating-2" name="rating" onChange={handleInputChange} value="40" />
           3<input type="radio" id="rating-3" name="rating" onChange={handleInputChange} value="60" />
           4<input type="radio" id="rating-4" name="rating" onChange={handleInputChange} value="80" />
           5<input type="radio" id="rating-5" name="rating" onChange={handleInputChange} value="100" />
        </label>

        <label htmlFor="content">Review Content
          <input id="content" type="text" name="content" onChange={handleInputChange} value={reviewRecord.content}/>
        </label>

        <div className="button-group">
          <button className="button" onClick={clearForm}>Clear Form</button>
          <input className="button" type="submit" value="Submit" ></input>
        </div>
      </form>
    </div>
  )
}

export default ReviewForm