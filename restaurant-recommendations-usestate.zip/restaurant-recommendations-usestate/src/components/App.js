import React, { useState } from "react"
import reviews from "../constants/reviews"
import restaurants from "../constants/restaurants"

import Restaurant from "./Restaurant"
import ReviewList from "./ReviewList"
import ReviewForm from "./ReviewForm"

const App = props => {
  const [reviews, setReviews] = useState(reviews)

  const reviewSubmitHandler = review => {
    setReviews([...reviews, review])
  }

  return (
    <div className="grid-container">
      <div className="grid-x">
        <div className="restaurants cell small-3">
          <h3>Restaurants</h3>
          <Restaurant all={restaurants}/>
        </div>

        <div className="reviews cell auto grid-x">
          
          <div className="cell">
            <h3>Reviews</h3>
            <ReviewList reviews={reviews} />
          </div>

          <div className="cell">
            <h3>Review Form</h3>
            <ReviewForm onReviewSubmit = {reviewSubmitHandler}/>
          </div>

        </div>
      </div>
    </div>
  )
}

export default App
